package com.entity;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Role {
    private Integer id;
    private String roleName;
    private Integer roleNumber;

}