package com.entity.jsonEntity;

import java.util.List;

public class DefaultDataResult {

    public int total;

    public List<?> rows;
}
